"""     This module is to say hello to the user     """


def hellofunc(name):
    print("Hello my dear friend. Thanks for calling me." , name )