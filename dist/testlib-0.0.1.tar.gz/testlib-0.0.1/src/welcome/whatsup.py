"""     This module is to ask about the well-being of the user     """


def askWellBeing():
    print("How are you my friend? I hope you are doing great in your life.")