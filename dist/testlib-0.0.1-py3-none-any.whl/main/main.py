from src.welcome import hello


def main():
    hello.hellofunc('Hola Mundo')
    print('FIN....')

